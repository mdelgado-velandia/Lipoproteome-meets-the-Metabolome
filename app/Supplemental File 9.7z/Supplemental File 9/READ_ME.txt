Figures "HDL_metabolites_CVD" and "LDL_metabolites_CVD" were redrawn from data published by: Pietzner M, Stewart ID, Raffler J, Khaw KT, Michelotti GA, Kastenmüller G, Wareham NJ, Langenberg C. Plasma metabolites to profile pathways in noncommunicable disease multimorbidity. Nat Med. 2021;27(3):471-479. doi: 10.1038/s41591-021-01266-0.


	

